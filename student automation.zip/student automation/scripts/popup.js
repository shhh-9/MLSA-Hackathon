document.addEventListener("DOMContentLoaded", () => {
    // Toggle buttons functionality
   const toggleOutlook = document.getElementById("toggleOutlook");
const toggleWhatsApp = document.getElementById("toggleWhatsApp");

// Update button appearance based on state
function updateButtonState(button, isActive) {
    button.textContent = isActive ? "ON" : "OFF";
    button.style.backgroundColor = isActive ? "#4CAF50" : "#ffeb3b";
    button.style.color = isActive ? "white" : "black";
}

chrome.storage.sync.get(["outlookScan", "whatsappScan"], (data) => {
    updateButtonState(toggleOutlook, data.outlookScan);
    updateButtonState(toggleWhatsApp, data.whatsappScan);
});

function toggleService(serviceName, button) {
    chrome.storage.sync.get(serviceName, (data) => {
        const newState = !data[serviceName];
        chrome.storage.sync.set({ [serviceName]: newState }, () => {
            updateButtonState(button, newState);
        });
    });
}

toggleOutlook.addEventListener("click", () => toggleService("outlookScan", toggleOutlook));
toggleWhatsApp.addEventListener("click", () => toggleService("whatsappScan", toggleWhatsApp));
    // Load deadlines
    loadDeadlines();
    
    // Button handlers
    document.getElementById('approveBtn').addEventListener('click', handleApproval);
    document.getElementById('declineBtn').addEventListener('click', handleDecline);
});

function toggleService(serviceName, button) {
    chrome.storage.sync.get(serviceName, (data) => {
        const newState = !data[serviceName];
        chrome.storage.sync.set({ [serviceName]: newState });
        button.textContent = newState ? "ON" : "OFF";
    });
}

function loadDeadlines() {
    

    const deadlineList = document.querySelector('.checkbox-container');
    chrome.storage.sync.get("deadlines", (data) => {
        deadlineList.innerHTML = '';
        if (data.deadlines && data.deadlines.length > 0) {
            data.deadlines.forEach((deadline) => {
                const label = document.createElement('label');
                label.innerHTML = `
                    <input type="checkbox" 
                           data-date="${deadline.date}" 
                           data-title="${deadline.title}"
                           data-id="${deadline.title}-${deadline.date}">
                    ${deadline.title}: ${deadline.date}
                `;
                deadlineList.appendChild(label);
            });
        }
    });
}

async function handleApproval() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    if (checkboxes.length === 0) {
        showStatus('Please select at least one deadline to approve', 'error');
        return;
    }

    showStatus('Processing...', 'info');
    
    try {
        const token = await getAuthToken();
        const results = [];
        
        for (const checkbox of checkboxes) {
            try {
                const eventDate = parseDateString(checkbox.dataset.date);
                console.log('Creating event for:', checkbox.dataset.title, eventDate);
                
                const result = await createCalendarEvent({
                    title: checkbox.dataset.title,
                    date: eventDate
                }, token);
                
                results.push(result);
                console.log('Event created:', result.htmlLink);
            } catch (error) {
                console.error('Error creating event:', error);
                showStatus(`Failed to create event: ${error.message}`, 'error');
            }
        }

        if (results.length > 0) {
            showStatus(`${results.length} events added to Google Calendar!`, 'success');
            await removeSelectedDeadlines(checkboxes);
            loadDeadlines();
        }
    } catch (error) {
        console.error('Approval error:', error);
        showStatus(`Error: ${error.message}`, 'error');
    }
}

function handleDecline() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    if (checkboxes.length === 0) {
        showStatus('Please select deadlines to decline', 'error');
        return;
    }
    
    showStatus('Removing declined deadlines...', 'info');
    removeSelectedDeadlines(checkboxes)
        .then(() => {
            showStatus('Declined deadlines removed', 'success');
            loadDeadlines();
        })
        .catch(error => {
            showStatus('Error removing deadlines: ' + error.message, 'error');
        });
}

function parseDateString(dateString) {
    const cleanedDate = dateString
        .replace(/,/g, '')
        .replace(/(\d+)(st|nd|rd|th)/, '$1')
        .replace(/\./g, '')
        .trim();

    const months = {
        'jan': 0, 'feb': 1, 'mar': 2, 'apr': 3, 'may': 4, 'jun': 5,
        'jul': 6, 'aug': 7, 'sep': 8, 'oct': 9, 'nov': 10, 'dec': 11
    };

    const dateParts = cleanedDate.split(/\s+/);
    if (dateParts.length !== 3) {
        throw new Error(`Invalid date format: ${dateString}`);
    }

    const day = parseInt(dateParts[0]);
    const monthName = dateParts[1].toLowerCase().substring(0, 3);
    const year = parseInt(dateParts[2]);

    if (!months[monthName] && months[monthName] !== 0) {
        throw new Error(`Invalid month: ${dateParts[1]}`);
    }

    return new Date(Date.UTC(year, months[monthName], day));
}

async function getAuthToken() {
    return new Promise((resolve, reject) => {
        chrome.identity.getAuthToken({ interactive: true }, (token) => {
            if (chrome.runtime.lastError || !token) {
                const errorMessage = chrome.runtime.lastError?.message || 'No token received';
                console.error('Auth error:', errorMessage);
                reject(new Error(`Authentication failed: ${errorMessage}`));
                return;
            }
            
            // Verify token validity
            fetch(`https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=${token}`)
                .then(response => {
                    if (!response.ok) throw new Error('Token validation failed');
                    return response.json();
                })
                .then(data => {
                    if (data.error_description) {
                        throw new Error(data.error_description);
                    }
                    resolve(token);
                })
                .catch(error => {
                    console.error('Token validation error:', error);
                    chrome.identity.removeCachedAuthToken({ token }, () => {
                        getAuthToken().then(resolve).catch(reject);
                    });
                });
        });
    });
}

async function createCalendarEvent(event, token) {
    try {
        const startDate = new Date(event.date);
        // Set to 9 AM UTC
        startDate.setUTCHours(9, 0, 0, 0);
        const endDate = new Date(startDate.getTime() + 3600000); // 1 hour duration

        const calendarEvent = {
            summary: event.title,
            start: {
                dateTime: startDate.toISOString(),
                timeZone: 'UTC'
            },
            end: {
                dateTime: endDate.toISOString(),
                timeZone: 'UTC'
            }
        };

        const response = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(calendarEvent)
        });

        const responseData = await response.json();
        
        if (!response.ok) {
            const errorMessage = responseData.error?.message || 'Unknown Google API error';
            throw new Error(errorMessage);
        }

        return responseData;
    } catch (error) {
        console.error('Event creation error:', error);
        throw new Error(`Failed to create event: ${error.message}`);
    }
}

async function removeSelectedDeadlines(selectedCheckboxes) {
    return new Promise((resolve) => {
        chrome.storage.sync.get("deadlines", (data) => {
            const selectedIds = Array.from(selectedCheckboxes).map(cb => cb.dataset.id);
            const remainingDeadlines = data.deadlines.filter(d => 
                !selectedIds.includes(`${d.title}-${d.date}`)
            );
            chrome.storage.sync.set({ deadlines: remainingDeadlines }, () => {
                resolve();
            });
        });
    });
}

function showStatus(message, type = 'info') {
    const statusDiv = document.getElementById('statusMessage');
    statusDiv.textContent = message;
    statusDiv.className = `status-message ${type}`;
    setTimeout(() => {
        statusDiv.textContent = '';
        statusDiv.className = 'status-message';
    }, 5000);
}