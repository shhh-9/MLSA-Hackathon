async function fetchOutlookEmails(token) {
    const endpoint = "https://graph.microsoft.com/v1.0/me/messages?$filter=contains(subject,'deadline')&$select=subject,body";
    
    try {
      const response = await fetch(endpoint, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      if (!response.ok) throw new Error('Failed to fetch emails');
      const data = await response.json();
      return processEmails(data.value);
    } catch (error) {
      console.error('Microsoft API error:', error);
      throw error;
    }
  }
  
  function processEmails(emails) {
    const deadlines = [];
    const dateRegex = /\b(\d{1,2} (January|February|March|April|May|June|July|August|September|October|November|December) \d{4})\b/gi;

  
    emails.forEach(email => {
      const content = `${email.subject} ${email.body.content}`;
      const dateMatch = content.match(dateRegex);
      
      if (dateMatch) {
        deadlines.push({
          title: email.subject,
          date: dateMatch[0],
          source: 'Outlook'
        });
      }
    });
  
    return deadlines;
  }
  
  export { fetchOutlookEmails };