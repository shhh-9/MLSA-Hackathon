// background.js
chrome.runtime.onInstalled.addListener(() => {
    console.log("Student Life Automator extension installed.");
    
    // Add test data initialization
    chrome.storage.sync.get("deadlines", (data) => {
        if (!data.deadlines || data.deadlines.length === 0) {
            const testDeadlines = [
                {
                    title: "CS101 Quiz",
                    date: "25 February 2025",
                    source: "Test"
                },
                {
                    title: "MT101 Assignment",
                    date: "26 February 2025",
                    source: "Test"
                },
                {
                    title: "ES111 Quiz",
                    date: "27 February 2025",
                    source: "Test"
                }
            ];
            
            chrome.storage.sync.set({ deadlines: testDeadlines });
            console.log("Added test deadlines");
        }
    });
});


chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && tab.url) {
        handleTabUpdate(tabId, tab.url);
    }
});

chrome.tabs.onActivated.addListener(({tabId}) => {
    chrome.tabs.get(tabId, (tab) => {
        if (tab.url) handleTabUpdate(tabId, tab.url);
    });
});

function handleTabUpdate(tabId, url) {
    if (url.includes("outlook.live.com") || url.includes("web.whatsapp.com")) {
        chrome.scripting.executeScript({
            target: { tabId },
            files: ["scripts/content.js"]
        });
        console.log(`Injected content script into ${url}`);
    }
}

// Improved message handling
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "newDeadlines") {
        chrome.storage.sync.get("deadlines", (data) => {
            const existing = new Set(data.deadlines?.map(d => `${d.title}-${d.date}`));
            const filtered = message.deadlines.filter(d => 
                !existing.has(`${d.title}-${d.date}`)
            );
            
            if (filtered.length > 0) {
                chrome.storage.sync.set({ 
                    deadlines: [...(data.deadlines || []), ...filtered]
                });
            }
        });
    }
    return true;
});