const MICROSOFT_CLIENT_ID = "YOUR_MICROSOFT_CLIENT_ID";
const MICROSOFT_SCOPES = ["User.Read", "Mail.Read"];

async function getMicrosoftToken() {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken(
      { interactive: true, account: { prompt: 'select_account' } },
      (token) => {
        if (chrome.runtime.lastError || !token) {
          reject(new Error(chrome.runtime.lastError?.message || 'Authentication failed'));
          return;
        }
        resolve(token);
      }
    );
  });
}

async function initializeMicrosoftAPI() {
  try {
    const token = await getMicrosoftToken();
    return token;
  } catch (error) {
    console.error('Microsoft auth error:', error);
    throw error;
  }
}

export { initializeMicrosoftAPI, getMicrosoftToken };