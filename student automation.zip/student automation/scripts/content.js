// Update the scanning functions to collect titles
function scanOutlookEmails() {
    let emails = document.querySelectorAll(".lvHighlightAllClass");
    let deadlines = [];
    
    emails.forEach(email => {
        const text = email.innerText;
        const dateMatch = text.match(/\b(\d{1,2} [A-Za-z]+ \d{4})\b/);
        if (dateMatch) {
            const titleMatch = text.match(/(Assignment|Quiz|Exam|Project)[^\n]+/i);
            deadlines.push({
                title: titleMatch ? titleMatch[0] : 'Deadline',
                date: dateMatch[0],
                source: 'Outlook'
            });
        }
    });

    if (deadlines.length > 0) {
        chrome.runtime.sendMessage({ 
            type: "newDeadlines", 
            source: "outlook", 
            deadlines 
        });
    }
}

function scanWhatsAppChats() {
    let messages = document.querySelectorAll('[data-pre-plain-text]');
    let deadlines = [];

    messages.forEach(msg => {
        const text = msg.innerText;
        const dateMatch = text.match(/\b(\d{1,2} [A-Za-z]+ \d{4})\b/);
        if (dateMatch) {
            const titleMatch = text.match(/(assignment|quiz|exam|project|deadline)[^\n]+/i);
            deadlines.push({
                title: titleMatch ? titleMatch[0] : 'Deadline',
                date: dateMatch[0],
                source: 'WhatsApp'
            });
        }
    });

    if (deadlines.length > 0) {
        chrome.runtime.sendMessage({ 
            type: "newDeadlines", 
            source: "whatsapp", 
            deadlines 
        });
    }
}

(function initScanners() {
    // WhatsApp message observer
    const observer = new MutationObserver(() => {
        if (window.location.host === "web.whatsapp.com") {
            scanWhatsAppChats();
        }
    });

    // Start observing when WhatsApp container exists
    const checkContainer = setInterval(() => {
        const mainDiv = document.querySelector('div[data-testid="conversation-panel-body"]');
        if (mainDiv) {
            observer.observe(mainDiv, {
                childList: true,
                subtree: true
            });
            clearInterval(checkContainer);
        }
    }, 1000);

    // Outlook scanning
    if (window.location.host === "outlook.live.com") {
        scanOutlookEmails();
        // Rescan when new emails load
        window.addEventListener('scroll', () => {
            if (window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 500) {
                scanOutlookEmails();
            }
        });
    }
})();
